import { Request, Response } from "express";
import multer from "multer";
import { promises as fs } from "fs";
import { z } from "zod";

// Configure multer for file uploads
const storage = multer.memoryStorage();
export const upload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      "audio/mp3",
      "audio/wav",
      "audio/mpeg",
      "text/plain",
      "application/pdf",
    ];

    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type"), false);
    }
  },
});

// Response types
interface ActionItem {
  person: string;
  task: string;
  deadline: string;
}

interface ProcessingResult {
  summary: string[];
  actionItems: ActionItem[];
  originalTranscript?: string;
}

// Transcribe audio using AssemblyAI
async function transcribeAudio(
  audioBuffer: Buffer,
  filename: string,
): Promise<string> {
  const apiKey = process.env.ASSEMBLYAI_API_KEY;
  if (!apiKey) {
    // Provide mock transcription for demo purposes when API key is not configured
    console.log("AssemblyAI API key not configured, using mock transcription");

    return `Mock Transcription for ${filename}:

Good morning everyone, thank you for joining today's meeting. Let's start by reviewing our progress from last week.

Sarah, can you give us an update on the development milestones? We're tracking well on the main features but I want to make sure we're addressing any blockers early.

Sure, we've completed about 80% of the core functionality. There are a couple of technical challenges with the integration layer that need some additional resources. I think we'll need to bring in a specialist to help resolve these by December 15th.

That sounds reasonable. Mike, what's the budget situation looking like for additional resources?

We have some flexibility in the Q4 budget. I can prepare a detailed proposal by the end of this week that outlines the cost and resource allocation needed.

Perfect. Emily, how are we doing on the timeline for the client deliverables?

We're on track for most items, but given the technical blockers Sarah mentioned, I think we should build in a small buffer. I'd like to propose adjusting our delivery timeline by two weeks to ensure quality.

That makes sense. Let's have everyone review Emily's proposed timeline adjustments and provide feedback by December 20th.

For next steps, I'd like to schedule a follow-up meeting for January 5th to review our progress. Everyone should prepare status reports on their respective areas.

Any other items before we wrap up? Great, thanks everyone for your time today.`;
  }

  try {
    // First, upload the audio file to AssemblyAI
    const uploadResponse = await fetch("https://api.assemblyai.com/v2/upload", {
      method: "POST",
      headers: {
        authorization: apiKey,
        "content-type": "application/octet-stream",
      },
      body: audioBuffer,
    });

    if (!uploadResponse.ok) {
      throw new Error(`Upload failed: ${uploadResponse.statusText}`);
    }

    const uploadData = await uploadResponse.json();
    const audioUrl = uploadData.upload_url;

    // Request transcription
    const transcriptResponse = await fetch(
      "https://api.assemblyai.com/v2/transcript",
      {
        method: "POST",
        headers: {
          authorization: apiKey,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          audio_url: audioUrl,
          language_code: "en_us",
        }),
      },
    );

    if (!transcriptResponse.ok) {
      throw new Error(
        `Transcription request failed: ${transcriptResponse.statusText}`,
      );
    }

    const transcriptData = await transcriptResponse.json();
    const transcriptId = transcriptData.id;

    // Poll for completion
    let transcript;
    let attempts = 0;
    const maxAttempts = 60; // 5 minutes max

    while (attempts < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait 5 seconds

      const pollResponse = await fetch(
        `https://api.assemblyai.com/v2/transcript/${transcriptId}`,
        {
          headers: {
            authorization: apiKey,
          },
        },
      );

      if (!pollResponse.ok) {
        throw new Error(`Polling failed: ${pollResponse.statusText}`);
      }

      transcript = await pollResponse.json();

      if (transcript.status === "completed") {
        return transcript.text;
      } else if (transcript.status === "error") {
        throw new Error(`Transcription failed: ${transcript.error}`);
      }

      attempts++;
    }

    throw new Error("Transcription timed out");
  } catch (error) {
    console.error("AssemblyAI transcription error:", error);
    throw new Error(
      `Failed to transcribe audio: ${error instanceof Error ? error.message : "Unknown error"}`,
    );
  }
}

// Extract text from PDF
async function extractTextFromPDF(pdfBuffer: Buffer): Promise<string> {
  try {
    // Dynamic import to avoid issues during server startup
    const pdf = await import("pdf-parse");
    const data = await pdf.default(pdfBuffer);
    return data.text;
  } catch (error) {
    console.error("PDF extraction error:", error);
    throw new Error("Failed to extract text from PDF");
  }
}

// Analyze transcript using OpenAI
async function analyzeTranscript(
  transcript: string,
): Promise<{ summary: string[]; actionItems: ActionItem[] }> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    // Provide mock response for demo purposes when API key is not configured
    console.log("OpenAI API key not configured, using mock response");

    return {
      summary: [
        "Discussion covered key project milestones and resource allocation for Q4 objectives",
        "Team reviewed current progress and identified potential blockers requiring immediate attention",
        "Budget considerations were addressed with preliminary approval for additional resources",
        "Next steps outlined with clear ownership and timeline expectations established",
        "Follow-up meeting scheduled to review implementation progress and address any concerns",
      ],
      actionItems: [
        {
          person: "Project Manager",
          task: "Finalize budget proposal and resource allocation plan",
          deadline: "End of this week",
        },
        {
          person: "Development Team Lead",
          task: "Address identified technical blockers and provide status update",
          deadline: "December 15, 2024",
        },
        {
          person: "Stakeholder Representative",
          task: "Review and approve proposed timeline adjustments",
          deadline: "December 20, 2024",
        },
        {
          person: "All Attendees",
          task: "Prepare progress reports for next review meeting",
          deadline: "January 5, 2025",
        },
      ],
    };
  }

  const prompt = `You are a meeting assistant. Analyze the following meeting transcript and provide:

1. A summary in exactly 3-5 bullet points (return as JSON array called "summary")
2. All action items in the format [Person] → [Task] (Deadline: [Date/Time or 'not specified']) (return as JSON array called "actionItems" with objects containing "person", "task", and "deadline" fields)

Transcript:
${transcript}

Return your response as valid JSON in this exact format:
{
  "summary": ["bullet point 1", "bullet point 2", ...],
  "actionItems": [
    {
      "person": "Person Name",
      "task": "Task description", 
      "deadline": "Deadline or 'not specified'"
    }
  ]
}`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        max_tokens: 1500,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.statusText}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;

    // Parse the JSON response
    try {
      const parsed = JSON.parse(content);
      return {
        summary: parsed.summary || [],
        actionItems: parsed.actionItems || [],
      };
    } catch (parseError) {
      console.error("Failed to parse OpenAI response:", content);
      throw new Error("Failed to parse AI analysis results");
    }
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    throw new Error(
      `Failed to analyze transcript: ${error instanceof Error ? error.message : "Unknown error"}`,
    );
  }
}

// Main processing handler
export const handleProcess = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const file = req.file;
    let transcript = "";

    // Process based on file type
    if (file.mimetype.startsWith("audio/")) {
      // Audio file - transcribe using AssemblyAI
      console.log("Transcribing audio file:", file.originalname);
      transcript = await transcribeAudio(file.buffer, file.originalname);
    } else if (file.mimetype === "text/plain") {
      // Text file - read directly
      transcript = file.buffer.toString("utf-8");
    } else if (file.mimetype === "application/pdf") {
      // PDF file - extract text
      console.log("Extracting text from PDF:", file.originalname);
      transcript = await extractTextFromPDF(file.buffer);
    } else {
      return res.status(400).json({ error: "Unsupported file type" });
    }

    if (!transcript || transcript.trim().length === 0) {
      return res.status(400).json({ error: "No text content found in file" });
    }

    // Analyze transcript using OpenAI
    console.log("Analyzing transcript with OpenAI...");
    const analysis = await analyzeTranscript(transcript);

    const result: ProcessingResult = {
      summary: analysis.summary,
      actionItems: analysis.actionItems,
      originalTranscript: file.mimetype.startsWith("audio/")
        ? transcript
        : undefined,
    };

    res.json(result);
  } catch (error) {
    console.error("Processing error:", error);
    res.status(500).json({
      error: error instanceof Error ? error.message : "Processing failed",
    });
  }
};
