import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Upload,
  FileAudio,
  FileText,
  Download,
  Mail,
  Moon,
  Sun,
  Loader2,
  CheckCircle2,
  Clock,
  User,
  Sparkles,
  Mic,
  MessageSquare,
} from "lucide-react";

type InputMode = "audio" | "transcript";
type ProcessingState =
  | "idle"
  | "uploading"
  | "processing"
  | "completed"
  | "error";

interface ActionItem {
  person: string;
  task: string;
  deadline: string;
}

interface ProcessingResult {
  summary: string[];
  actionItems: ActionItem[];
  originalTranscript?: string;
}

export default function Index() {
  const [darkMode, setDarkMode] = useState(false);
  const [inputMode, setInputMode] = useState<InputMode>("transcript");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [processingState, setProcessingState] =
    useState<ProcessingState>("idle");
  const [result, setResult] = useState<ProcessingResult | null>(null);
  const [emailAddress, setEmailAddress] = useState("");
  const [dragActive, setDragActive] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Toggle dark mode
  const toggleDarkMode = useCallback(() => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  }, [darkMode]);

  // Handle file selection
  const handleFileSelect = useCallback(
    (file: File) => {
      const isValidAudio =
        inputMode === "audio" &&
        (file.type === "audio/mp3" ||
          file.type === "audio/wav" ||
          file.type === "audio/mpeg");
      const isValidText =
        inputMode === "transcript" &&
        (file.type === "text/plain" || file.type === "application/pdf");

      if (!isValidAudio && !isValidText) {
        toast({
          title: "Invalid file type",
          description: `Please select a valid ${inputMode === "audio" ? "audio (.mp3, .wav)" : "text (.txt, .pdf)"} file.`,
          variant: "destructive",
        });
        return;
      }

      setSelectedFile(file);
      toast({
        title: "File selected",
        description: `${file.name} is ready for processing.`,
      });
    },
    [inputMode, toast],
  );

  // Handle drag and drop
  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFileSelect(e.dataTransfer.files[0]);
      }
    },
    [handleFileSelect],
  );

  // Process file using backend API
  const handleSummarize = async () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to process.",
        variant: "destructive",
      });
      return;
    }

    setProcessingState("processing");

    try {
      const formData = new FormData();
      formData.append("file", selectedFile);

      const response = await fetch("/api/process", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        let errorMessage = "Processing failed";
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch (parseError) {
          // If we can't parse the error response, use the status text
          errorMessage = response.statusText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      const result: ProcessingResult = await response.json();
      setResult(result);
      setProcessingState("completed");

      toast({
        title: "Processing complete!",
        description: "Meeting summary and action items have been generated.",
      });

      // Check if this was a demo response (when API keys are not configured)
      if (
        result.summary.some((item) =>
          item.includes("Discussion covered key project milestones"),
        )
      ) {
        toast({
          title: "Demo Mode Active",
          description:
            "This is a mock response. Add API keys to process real content.",
          variant: "default",
        });
      }
    } catch (error) {
      console.error("Processing error:", error);
      setProcessingState("error");

      toast({
        title: "Processing failed",
        description:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Download results
  const handleDownload = () => {
    if (!result) return;

    const content = `AI Meeting Summary & Action Items
Generated on ${new Date().toLocaleDateString()}

SUMMARY:
${result.summary.map((item, index) => `${index + 1}. ${item}`).join("\n")}

ACTION ITEMS:
${result.actionItems
  .map(
    (item, index) =>
      `${index + 1}. [${item.person}] → ${item.task} (Deadline: ${item.deadline})`,
  )
  .join("\n")}

${result.originalTranscript ? `\nORIGINAL TRANSCRIPT:\n${result.originalTranscript}` : ""}`;

    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meeting-summary-${new Date().toISOString().split("T")[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Send email
  const handleSendEmail = () => {
    if (!emailAddress || !result) return;

    toast({
      title: "Email sent!",
      description: `Meeting summary has been sent to ${emailAddress}`,
    });
    setEmailAddress("");
  };

  // Load example content
  const loadExample = () => {
    const exampleTranscript = `Meeting Notes - Q4 Planning Session
Date: December 5, 2024
Attendees: Sarah Chen (Engineering), Mike Rodriguez (Product), Emily Watson (Marketing), David Kim (Design)

Sarah: Good morning everyone. Let's start with our Q4 progress review. We've completed the security audit and found some minor issues that need addressing by December 15th.

Mike: Thanks Sarah. From the product side, we've identified three key features for Q1 development. I'll need to prepare the hiring plan and budget breakdown by December 20th.

Emily: Marketing results are looking great - we're seeing a 25% increase in user engagement from our latest campaign. I'll have the full metrics report ready by December 12th.

David: I've been working on the new feature specifications. Mike, can you review and approve them by January 5th?

Mike: Absolutely. Also, our budget allocation for additional developers has been approved for Q1 2024.

Sarah: Perfect. Let's schedule our next milestone review for January 15th with the stakeholder presentation.

Emily: Sounds good. I'll start preparing the presentation materials.

Sarah: Great, I think that covers everything for today. Thank you all.`;

    const exampleFile = new File([exampleTranscript], "example-meeting.txt", {
      type: "text/plain",
    });
    setInputMode("transcript");
    setSelectedFile(exampleFile);

    toast({
      title: "Example loaded",
      description: "Sample meeting transcript ready for processing.",
    });
  };

  return (
    <div
      className={`min-h-screen transition-colors duration-300 ${darkMode ? "dark" : ""}`}
    >
      <div className="bg-background text-foreground">
        {/* Header */}
        <header className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="bg-primary text-primary-foreground p-2 rounded-lg">
                  <Sparkles className="h-6 w-6" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">AI Meeting Summarizer</h1>
                  <p className="text-sm text-muted-foreground">
                    Transform meetings into actionable insights
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <Button variant="outline" size="sm" onClick={loadExample}>
                  <FileText className="h-4 w-4 mr-2" />
                  Try Example
                </Button>
                <Button variant="outline" size="sm" onClick={toggleDarkMode}>
                  {darkMode ? (
                    <Sun className="h-4 w-4" />
                  ) : (
                    <Moon className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold tracking-tight mb-4">
              Extract Value from Every Meeting
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Upload your meeting audio or transcript and get AI-powered
              summaries with clear action items.
            </p>
          </div>

          {/* Main Interface */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="h-5 w-5" />
                  <span>Upload Meeting Content</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Input Mode Toggle */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Input Type</Label>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Mic className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Audio</span>
                      <Switch
                        checked={inputMode === "transcript"}
                        onCheckedChange={(checked) =>
                          setInputMode(checked ? "transcript" : "audio")
                        }
                      />
                      <span className="text-sm">Transcript</span>
                      <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {inputMode === "audio"
                      ? "Accepts: .mp3, .wav files"
                      : "Accepts: .txt, .pdf files"}
                  </Badge>
                </div>

                {/* File Upload Area */}
                <div
                  className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept={inputMode === "audio" ? ".mp3,.wav" : ".txt,.pdf"}
                    onChange={(e) =>
                      e.target.files?.[0] && handleFileSelect(e.target.files[0])
                    }
                    className="hidden"
                  />

                  {selectedFile ? (
                    <div className="space-y-2">
                      <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto">
                        {inputMode === "audio" ? (
                          <FileAudio className="h-6 w-6" />
                        ) : (
                          <FileText className="h-6 w-6" />
                        )}
                      </div>
                      <p className="font-medium">{selectedFile.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Change File
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="text-muted-foreground p-3 rounded-full w-fit mx-auto">
                        {inputMode === "audio" ? (
                          <FileAudio className="h-8 w-8" />
                        ) : (
                          <FileText className="h-8 w-8" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">
                          Drag & drop your {inputMode} file here
                        </p>
                        <p className="text-sm text-muted-foreground">
                          or click to browse
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Select File
                      </Button>
                    </div>
                  )}
                </div>

                {/* Process Button */}
                <Button
                  className="w-full h-12"
                  onClick={handleSummarize}
                  disabled={!selectedFile || processingState === "processing"}
                  size="lg"
                >
                  {processingState === "processing" ? (
                    <>
                      <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                      Processing Meeting...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-5 w-5 mr-2" />
                      Summarize Meeting
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Results Section */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CheckCircle2 className="h-5 w-5" />
                  <span>Meeting Insights</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {processingState === "idle" && (
                  <div className="text-center py-12 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>
                      Your meeting summary and action items will appear here
                    </p>
                  </div>
                )}

                {processingState === "processing" && (
                  <div className="text-center py-12">
                    <Loader2 className="h-12 w-12 mx-auto mb-4 animate-spin text-primary" />
                    <p className="text-muted-foreground mb-2">
                      {inputMode === "audio"
                        ? "Converting audio to text and analyzing..."
                        : "Analyzing transcript..."}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {inputMode === "audio"
                        ? "This may take a few minutes for audio files"
                        : "This should take less than 30 seconds"}
                    </p>
                  </div>
                )}

                {processingState === "error" && (
                  <div className="text-center py-12 text-destructive">
                    <div className="bg-destructive/10 text-destructive p-3 rounded-full w-fit mx-auto mb-4">
                      <MessageSquare className="h-12 w-12" />
                    </div>
                    <p className="font-medium mb-2">Processing failed</p>
                    <p className="text-sm text-muted-foreground">
                      Please check your file and try again
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-4"
                      onClick={() => setProcessingState("idle")}
                    >
                      Try Again
                    </Button>
                  </div>
                )}

                {result && processingState === "completed" && (
                  <div className="space-y-6">
                    {/* Summary Section */}
                    <div>
                      <h3 className="font-semibold mb-3 flex items-center space-x-2">
                        <MessageSquare className="h-4 w-4 text-primary" />
                        <span>Summary</span>
                      </h3>
                      <div className="space-y-2">
                        {result.summary.map((item, index) => (
                          <div
                            key={index}
                            className="flex items-start space-x-2"
                          >
                            <div className="bg-primary text-primary-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs font-medium mt-0.5">
                              {index + 1}
                            </div>
                            <p className="text-sm leading-relaxed flex-1">
                              {item}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    {/* Action Items Section */}
                    <div>
                      <h3 className="font-semibold mb-3 flex items-center space-x-2">
                        <CheckCircle2 className="h-4 w-4 text-primary" />
                        <span>Action Items</span>
                      </h3>
                      <div className="space-y-3">
                        {result.actionItems.map((item, index) => (
                          <div
                            key={index}
                            className="bg-muted/50 rounded-lg p-3 space-y-2"
                          >
                            <div className="flex items-center space-x-2">
                              <User className="h-4 w-4 text-primary" />
                              <span className="font-medium text-sm">
                                {item.person}
                              </span>
                            </div>
                            <p className="text-sm pl-6">{item.task}</p>
                            <div className="flex items-center space-x-2 pl-6">
                              <Clock className="h-3 w-3 text-muted-foreground" />
                              <span className="text-xs text-muted-foreground">
                                {item.deadline}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    {/* Actions */}
                    <div className="space-y-4">
                      <Button className="w-full" onClick={handleDownload}>
                        <Download className="h-4 w-4 mr-2" />
                        Download Summary
                      </Button>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-sm">
                          Share via Email
                        </Label>
                        <div className="flex space-x-2">
                          <Input
                            id="email"
                            type="email"
                            placeholder="Enter email address"
                            value={emailAddress}
                            onChange={(e) => setEmailAddress(e.target.value)}
                            className="flex-1"
                          />
                          <Button
                            variant="outline"
                            onClick={handleSendEmail}
                            disabled={!emailAddress}
                          >
                            <Mail className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Features Grid */}
          <div className="mt-16 grid md:grid-cols-3 gap-6">
            <Card className="text-center p-6">
              <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto mb-4">
                <Mic className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Audio Processing</h3>
              <p className="text-sm text-muted-foreground">
                Upload MP3 or WAV files and get automatic transcription with
                AI-powered analysis.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto mb-4">
                <CheckCircle2 className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Action Extraction</h3>
              <p className="text-sm text-muted-foreground">
                Automatically identify action items with assigned persons and
                deadlines.
              </p>
            </Card>

            <Card className="text-center p-6">
              <div className="bg-primary/10 text-primary p-3 rounded-full w-fit mx-auto mb-4">
                <Download className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Export & Share</h3>
              <p className="text-sm text-muted-foreground">
                Download summaries as text files or share directly via email.
              </p>
            </Card>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-border/40 mt-16">
          <div className="container mx-auto px-4 py-6">
            <div className="text-center text-sm text-muted-foreground">
              <p>
                © 2024 AI Meeting Summarizer. Powered by advanced AI
                technology.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
